#!/bin/bash

if [ `whoami` != "root" ]; then
  echo "You need the root access to OnionMail"
  exit
  fi
  
if [ ! -d __MAILDIR__ ]; then
   echo "Server not generated!"
   exit
   fi

if [ "$1" = "stop" ]; then
  service onionmail stop
  exit
  fi

if [ "$1" = "start" ]; then
	
	if [ ! -f __RAMPASS__ ]; then
		echo "Password not found in RAM"
		exit
		fi

   service onionmail start
 exit
 fi

echo "Usage: onionmail stop | start"
