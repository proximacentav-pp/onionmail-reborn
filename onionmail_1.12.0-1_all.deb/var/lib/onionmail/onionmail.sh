#!/bin/bash

if [ `whoami` != "root" ]; then
  echo "You need the root access to OnionMail"
  exit
  fi
if [ ! -d /var/onionmail ]; then
   echo "Server not generated!"
   exit
   fi

if [ "$1" = "stop" ]; then
  service onionmail start
  exit
  fi

if [ "$1" = "start" ]; then
	if [ ! -f /etc/onionmail/bootToken ]; then
		echo "Password not found in etc"
		exit
		fi

 service onionmail stop
 exit
 fi

echo "Usage: onionmail stop | start"
